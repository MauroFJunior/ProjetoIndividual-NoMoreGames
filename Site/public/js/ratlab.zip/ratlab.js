var html = `
    <button class="butVis" onclick="setVisuals()">DEV MODE</button>
    <div id="telaRat"></div><br><br>
    <input type="text" id="get_input" oninput="checkInput()"><br><br>
    <button onclick="move(get_input.value.split(''))">Start</button>`
    ;

var mapa =
    [
        [1, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0]
    ];

var mapa2 = [
    [1, 0, 0, 0, 0],
    [0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0]
];

var mapa3 = [
    [1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0]
];

var mapa4 = [
    [1, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0]
];

var player = [0, 0];
var visuals = true;

function drawRatlab(idDiv) {
    var div = document.getElementById(`${idDiv}`);
    div.innerHTML = html;
    drawTela();
}



function setVisuals() {
    if (visuals == false) visuals = true;
    else visuals = false;

    drawTela();

}

function checkInput() {
    if (!'cbed'.includes(get_input.value[get_input.value.length - 1])) {
        get_input.value = get_input.value.slice(0, -1);
    }
}

function move(command) {

    for (let i = 0; i < command.length; i++) {
        setTimeout(() => checkCondition(command[i].toLowerCase()), i * 300);
    }
}

function checkCondition(dir) {
    var movimento = [0, 0]
    console.log('entrei no check')
    if (dir == 'd') movimento = [0, 1];
    else if (dir == 'b') movimento = [1, 0];
    else if (dir == 'c') movimento = [-1, 0];
    else movimento = [0, -1];

    if (mapa[player[0] + movimento[0]][player[1] + movimento[1]] == 0) {
        console.log('andei')
        mapa[player[0]][player[1]] = 0;
        mapa[player[0] + movimento[0]][player[1] + movimento[1]] = 1;
    } else if
        (
        (player[0] + movimento[0]) >= mapa.length ||
        (player[1] + movimento[1]) >= mapa[0].length ||
        (player[0] + movimento[0]) < 0 ||
        (player[1] + movimento[1]) < 0) {
        return;
    }

    player = [(player[0] + movimento[0]), (player[1] + movimento[1])];


    drawTela();
}

function drawTela() {
    tela = document.getElementById("telaRat")
    tela.innerHTML = '';
    var linhaAtual = ''

    if (visuals == false) {
        for (i = 0; i < mapa[0].length; i++) {
            tela.innerHTML += `${mapa[i].join(" ")}<br>`;
        }
    } else {
        for (i = 0; i < mapa.length; i++) {
            tela.innerHTML += `<div id="linha${i}" class='linha'></div>`;
            linhaAtual = `linha${i}`;
            for (j = 0; j < mapa[0].length; j++) {
                if (mapa[i][j] == 0) {
                    document.getElementById(linhaAtual).innerHTML += `<div class='caminho'></div>`
                }
                else if (mapa[i][j] == 1) {
                    document.getElementById(linhaAtual).innerHTML += `<div class='jogador'></div>`
                }
            }
        }
    }
}
